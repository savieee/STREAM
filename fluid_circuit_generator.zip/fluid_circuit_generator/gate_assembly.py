"""
Manage the whole Assembly including Logic Gates and Pipe System
Handles high level analysis and claculations like propagation delay
Keeps track of gates, connections, and check for duplicates
"""


import json
import os
import sys
import importlib.util
from math import sin, cos, acos, pi
import numpy as np
import bpy
import mathutils

# pipe_system_spec = importlib.util.spec_from_file_location("pipe_system.py", "/Users/lhwang/Documents/GitHub/RMG Project/Fluid-Circuit-Generator/pipe_system.py")
# pipe_system = importlib.util.module_from_spec(pipe_system_spec)
# sys.modules["pipe_system.py"] = pipe_system
# pipe_system_spec.loader.exec_module(pipe_system)

# import_gate_spec = importlib.util.spec_from_file_location("import_gate.py", "/Users/lhwang/Documents/GitHub/RMG Project/Fluid-Circuit-Generator/import_gate.py")
# import_gate = importlib.util.module_from_spec(import_gate_spec)
# sys.modules["import_gate.py"] = import_gate
# import_gate_spec.loader.exec_module(import_gate)

import fluid_circuit_generator.pipe_system as pipe_system
import fluid_circuit_generator.import_gate as import_gate



class GateAssembly:
  """
  Gate Assembly object
  Only create one, have one Pipe System object and a dictionary of Logic Gate object
  """

  stage_height = 1
  stage_margin = .5
  tip_offset = 0.1
  unit_dimention = 1


  def __init__(self):

    self.pipe_system = pipe_system.PipeSystem()
    # {gate_name : Logic_Gate Class Object}
    self.logic_gate_dict = {}
    # {port_name : coord}
    # gate_name for free end port is "FREE_END"
    self.free_end_port_dict = {}
    # [(start_coord, end_coord)]
    self.to_connect_list = []
    # {start : [(end, propagation_delay) ] }
    self.connection_dict = {}
    # list of all connection grounps (ports that are interconnected)
    # store as (gate_name, port_name)
    self.connection_group_list = []
    # list of bpy objects that could potentially be blocking pipe generation
    self.obstacle_list = []

    # stores user related error messages
    self.error_message_list = []
    # stores user related warning messages
    self.warning_message_list = []




  def add_gate(self, name, stl_path):
    """Add logic gate"""
    new_gate = import_gate.LogicGate(name, stl_path)
    self.logic_gate_dict[name] = new_gate
    return new_gate


  def add_free_end_port(self, port_name, port_coord):
    """Add free end port"""
    if port_name in self.free_end_port_dict:
      self.register_warning_message(f"WARNING: Port name {port_name}, coord {self.free_end_port_dict[port_name]} already exists in free_end_port_dict, now replaced with coord {port_coord}")
    self.free_end_port_dict[port_name] = port_coord
    return port_coord


  def prepare_for_connection(self, pipe_dimention=None, unit_dimention=1, tip_length=None, stage_height=1, stage_margin=.5, tip_offset=.1):
    """
    Set grid to fit gate ports
    Check if ports are in valid position
    Get all obstacles
    Call this function before making connections
    Don't make connection if this return False
    """
    self.stage_height = stage_height
    self.stage_margin = stage_margin
    self.tip_offset = tip_offset
    self.unit_dimention = unit_dimention

    max_real_dimention = (0,0,0)
    is_port_valid = True  # within valid dimensions
    # check gates
    for gate in self.logic_gate_dict.values():
      max_real_dimention = tuple(map(max, max_real_dimention, gate.get_max_pos()))
      is_port_valid &= gate.check_port_valid()
    # check free_end_port_dict
    for port_coord in self.free_end_port_dict.values():
      max_real_dimention = tuple(map(max, max_real_dimention, port_coord))

    max_grid_dimention = tuple(map(lambda x: int(x//unit_dimention)+1, max_real_dimention))
    self.obstacle_list = self.get_obstacle_objects()
    obstacles_world = self.get_obstacle_coord(self.obstacle_list, max_grid_dimention, unit_dimention, pipe_dimention)
    obstacles = list(map(lambda coord: (coord[0]//unit_dimention, coord[1]//unit_dimention, coord[2]//unit_dimention), obstacles_world))
    print("Registering obstacles:\n", obstacles)
    self.pipe_system.reset_grid(max_grid_dimention, pipe_dimention, unit_dimention, tip_length, obstacles)

    return is_port_valid



  def get_obstacle_objects(self):
    ingore_names = ["Test Tube", "Test Stage", "Test Tip", "Current Selection"]
    obstacle_list = []
    print("Current Objects:", list(bpy.data.objects))
    for obj in bpy.data.objects:
      if obj.name not in ingore_names and obj.gate_property.stl_file_path == "":
        obstacle_list.append(obj)
    print("Obstacle Object List:\n", obstacle_list)
    return obstacle_list


  def get_obstacle_coord(self, obstacle_list, max_grid_dimention, unit_dimention, pipe_dimention):
    """
    Check all coord in grid for collision
    return coords that are covered by obstacle in world space
    """
    print("IN FUNC Obstacle Object List:\n", obstacle_list)

    # collision_radius = unit_dimention/2 - pipe_dimention[1] # half unit - outer dimension
    collision_radius = unit_dimention/2
    # collision_radius = 2
    collision_list = []
    coord_list = []
    for x in range(max_grid_dimention[0]+1):
      for y in range(max_grid_dimention[1]+1):
        for z in range(max_grid_dimention[2]+1):
          coord = (x*unit_dimention, y*unit_dimention, z*unit_dimention)
          coord_list.append(coord)
    for obj in obstacle_list:
      this_collision = self.check_coord_in_object(coord_list, obj, collision_radius)
      collision_list.extend(this_collision)
    return collision_list


  def check_coord_in_object(self, coord_list, obj, dist=0):
    """
    Check if a list of point with given coordinates is inside or near the given object.
    The check is reliant on vertex normals
    Remesh is needed to clean up the model and avoid weird normals
    return the points that collide.
    """

    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.duplicate()
    remesh_obj = bpy.context.active_object

    # remesh to aviod random boolean cut errors
    modifier_name = "Remesh"
    remesh_obj.modifiers.new(modifier_name, "REMESH")
    remesh_obj.modifiers[modifier_name].mode = "VOXEL"
    # remesh_obj.modifiers[modifier_name].voxel_size = max(0.1, 0.1*dist)
    remesh_obj.modifiers[modifier_name].voxel_size = 0.1
    bpy.ops.object.modifier_apply(modifier = modifier_name)

    # remesh_obj = obj
    check_result_list = []
    collision_list = []

    for coord in coord_list:
      point = mathutils.Vector(coord)
      point_local = remesh_obj.matrix_world.inverted() @ point

      _, closest_local, nor_local, _ = remesh_obj.closest_point_on_mesh(point_local)

      closest_world = remesh_obj.matrix_world @ closest_local
      nor_world = remesh_obj.matrix_world.to_3x3() @ nor_local  # Ignore translation for normals

      direction = closest_world - point
      is_close = direction.length < dist
      # is_inside = direction.dot(nor_world) > 0 and direction.length<min(obj.dimensions)/2
      is_inside = direction.dot(nor_world) > 0

      if is_close | is_inside:
        bpy.ops.mesh.primitive_cube_add(location = coord, size=.5)
        bpy.ops.mesh.primitive_uv_sphere_add(radius=.1, location=closest_world)
        print("created point: ", bpy.context.active_object.name)
      # bpy.ops.object.delete()
        check_result_list.append(is_close | is_inside)
        collision_list.append(coord)
      
    remesh_obj.select_set(True)
    bpy.context.view_layer.objects.active = remesh_obj
    bpy.ops.object.delete()
    return collision_list


  def add_connection(self, gate_port_start, gate_port_end):
    """
    Function to connect two ports with (gate_name, port_name)
    Also check if connection already exists
    """
    start_in_group = None
    end_in_group = None
    for group in self.connection_group_list:
      if gate_port_start in group:
        start_in_group = group
      if gate_port_end in group:
        end_in_group = group

    # both new
    if not start_in_group and not end_in_group:
      self.connection_group_list.append([gate_port_start, gate_port_end])
    # start new
    elif not start_in_group and end_in_group:
      end_in_group.append(gate_port_start)
    # end new
    elif start_in_group and not end_in_group:
      start_in_group.append(gate_port_end)
    # in same group
    elif start_in_group and end_in_group and start_in_group is end_in_group:
      self.register_warning_message(f"WARNING: Connection already exists between {gate_port_start} and {gate_port_end}")
      return
    # in different group
    elif start_in_group and end_in_group and start_in_group is not end_in_group:
      start_in_group.extend(end_in_group)
      self.connection_group_list.remove(end_in_group)

    self.create_port_connection(gate_port_start, gate_port_end)


  def create_port_connection(self, gate_port_start, gate_port_end):
    """Helper Function"""
    gate_start, port_start = gate_port_start
    gate_end, port_end = gate_port_end
    start_port = self.get_gate_port_coord(gate_start, port_start)
    end_port = self.get_gate_port_coord(gate_end, port_end)

    self.to_connect_list.append((start_port, end_port))
    # self.pipe_system.connect_two_port(start_port, end_port)


  def get_gate_port_coord(self, gate_name, port_name):
    """Helper function"""
    if gate_name == "FREE_END":
      return self.free_end_port_dict[port_name]

    if gate_name in self.logic_gate_dict:
      return self.logic_gate_dict[gate_name].get_port_coord(port_name)
    else:
      print(f"Error: Gate name: {gate_name} doesn't exist in logic_gate_dict: {self.logic_gate_dict.keys()}")
      return None


  def make_connections(self):
    """
    Wraper function
    Make all the connections after adding all of them
    """
    self.pipe_system.to_connect_list = self.to_connect_list[:]
    for connection in self.to_connect_list:
      self.pipe_system.connect_two_port(connection[0], connection[1])




  def update_connection_dict(self):
    """Load connection info from pipe_system and logic_gate into connection_dict with propagation delay"""
    self.pipe_system.finish_up_everything()
    # get connection from pipe_system.connection_graph
    for key,value in self.pipe_system.connection_graph.items():
      connection_list = []
      for connection in value:
        path = connection[1]
        # calculate propagation_delay
        propagation_delay = len(path) * .05

        connection_list.append((connection[0], propagation_delay))
      self.connection_dict[key] = connection_list
    print("Gate Assembly connection_dict updated from Pipe System connection_graph")

    # get connection form logic_gate.connection_dict
    for gate in self.logic_gate_dict.values():
      for key,value in gate.connection_dict.items():
        key_port_coord = gate.get_port_coord(key)
        connection_list = []
        for connection in value:
          port_coord = gate.get_port_coord(connection[0])
          propagation_delay = connection[1]
          connection_list.append((port_coord, propagation_delay))
        if key_port_coord in self.connection_dict:
          self.connection_dict[key_port_coord].extend(connection_list)
        else:
          self.connection_dict[key_port_coord] = connection_list
    print("Gate Assembly connection_dict updated from Logic Gate connection_dict")

    print("Gate Assembly connection_dict fully updated")
    self.print_connection_dict()


  def round_coord(self, coord):
    """Helper function"""
    return tuple(map(lambda x: round(x,2), coord))
    # return coord



  def get_propagation_delay(self, start_gate_port, end_gate_port):
    """Find path between two given ports and return the propagation delay"""
    if start_gate_port == end_gate_port:
      self.register_warning_message(f"WARNING: Looking for propergation delay to the same port {start_gate_port}")
      return 0

    start_coord = self.get_gate_port_coord(start_gate_port[0], start_gate_port[1])
    end_coord = self.get_gate_port_coord(end_gate_port[0], end_gate_port[1])

    if (not start_coord) or (not end_coord):  # either don't exist
      return float('-inf')

    # Breath First Search
    search_queue = []
    visited_list = []
    last_visited = {}

    search_queue.append(start_coord)

    while search_queue:
      this_coord = search_queue.pop(0)

      # found
      if this_coord is end_coord:
        found_path = []
        total_propegation_delay = 0
        current_coord = this_coord
        # trace back and get delay
        while current_coord is not start_coord:
          found_path.insert(0, current_coord)
          last_visited_coord = last_visited[current_coord]
          current_delay = self.get_delay(last_visited_coord, current_coord)
          if current_delay is None:
            print("Error: Problem with get_delay")
            return float('-inf')
          total_propegation_delay += current_delay
          current_coord = last_visited_coord

        total_propegation_delay = round(total_propegation_delay,4)
        print(f"Found path: {found_path}")
        print(f"Total Propegation Delay: {total_propegation_delay}")
        return total_propegation_delay

      # get neighbor list
      this_neighbor_list = []
      for dest in self.connection_dict[this_coord]:
        this_neighbor_list.append(dest[0])
      # add neighbors to search queue
      for neighbor in this_neighbor_list:
        if not (neighbor in visited_list) and (neighbor not in search_queue):
          search_queue.append(neighbor)
          last_visited[neighbor] = this_coord

      visited_list.append(this_coord)

    return float('inf')


  def get_delay(self, coord, dest):
    """Helper Function"""
    if coord not in self.connection_dict:
      print(f"Error: Coord {coord} not in connection_dict")
      return None
    dest_list = self.connection_dict[coord]
    for this_dest, this_delay in dest_list:
      if dest == this_dest:
        return this_delay
    print(f"Error: Destination {dest} not in dest_list of {coord}, dest_list: {dest_list}")
    return None




  def add_stage(self):
    """
    Call this function to auto generate stage under each logic gate
    Only call after update_connection_dict()
    Note: this process will significantly add to program run time
    """
    offset = self.tip_offset
    stage_obj_list = []

    for gate in self.logic_gate_dict.values():
      # calculate stage dimentions
      gate_max_pos = gate.get_max_pos()
      gate_min_pos = gate.get_min_pos()
      stage_margin = 2 * (self.stage_margin + self.pipe_system.pipe_dimention[0] + self.pipe_system.pipe_dimention[1])
      stage_x_dim = gate_max_pos[0] - gate_min_pos[0] + stage_margin
      stage_y_dim = gate_max_pos[1] - gate_min_pos[1] + stage_margin
      stage_z_dim = min(self.stage_height, gate_min_pos[2]-offset)   # stage lower bounded by xy plane

      stage_x_pos = (gate_max_pos[0] + gate_min_pos[0])/2
      stage_y_pos = (gate_max_pos[1] + gate_min_pos[1])/2
      stage_z_pos = gate_min_pos[2] - offset - stage_z_dim/2

      bpy.ops.mesh.primitive_cube_add()
      stage_object = bpy.context.active_object
      stage_object.dimensions = (stage_x_dim, stage_y_dim, stage_z_dim)
      stage_object.location = (stage_x_pos, stage_y_pos, stage_z_pos)
      stage_object.name = f"Stage-{gate.gate_obj.name}"

      # stage_min_range = tuple(map(lambda a,b: a-b/2-1, (stage_x_pos, stage_y_pos, stage_z_pos), (stage_x_dim, stage_y_dim, stage_z_dim)))
      # stage_max_range = tuple(map(lambda a,b: a+b/2+1, (stage_x_pos, stage_y_pos, stage_z_pos), (stage_x_dim, stage_y_dim, stage_z_dim)))
      # print(f"STAGE: pos: {(stage_x_pos, stage_y_pos, stage_z_pos)}, range: {stage_min_range}-{stage_max_range}")

      to_cut_path_list = []
      for path_coord_list in self.pipe_system.connection_dict.values():
        # collect path within range of stage
        to_cut_coord = []
        for coord in path_coord_list:
          if self.in_stage_range((stage_x_dim, stage_y_dim, stage_z_dim), (stage_x_pos, stage_y_pos, stage_z_pos), coord):
            to_cut_coord.append(coord)
          else:
            if to_cut_coord:
              to_cut_path_list.append(to_cut_coord[:])
            to_cut_coord.clear()
        # clear list at the end
        if to_cut_coord:
          to_cut_path_list.append(to_cut_coord[:])
      print(f"Path in range of stage at {(stage_x_pos, stage_y_pos, stage_z_pos)}, Path list: {to_cut_path_list}")

      for to_cut_path in to_cut_path_list:
        if len(to_cut_path) < 2:
          continue
        # make solid tube from to_cut_path_list and cut out from stage
        to_cut_sylinder = self.make_solid_sylinder(f"Cut_{(stage_x_pos, stage_y_pos, stage_z_pos)}", to_cut_path)
        self.cut_out_with_boolean(stage_object, to_cut_sylinder)

      self.add_guide_arrow(gate.gate_obj, stage_object)
      stage_obj_list.append(stage_object)
    return stage_obj_list



  def in_stage_range(self, stage_dim, stage_pos, coord):
    """Helper Function"""
    stage_min_range = tuple(map(lambda a,b: a-b/2-1, stage_pos, stage_dim))
    stage_max_range = tuple(map(lambda a,b: a+b/2+1, stage_pos, stage_dim))
    in_range = tuple(map(lambda a,b,c: a<=c and c<=b, stage_min_range, stage_max_range, coord))
    return in_range[0] & in_range[1] & in_range[2]


  def make_solid_sylinder(self, name, coord_list):
    """Helper Function"""
    # standard create tube
    curve_data = bpy.data.curves.new(name, type = "CURVE")
    curve_data.dimensions = "3D"

    polyline = curve_data.splines.new("POLY")
    polyline.points.add(len(coord_list)-1)
    for i, coord in enumerate(coord_list):
      x,y,z = coord
      polyline.points[i].co = (x,y,z,1)

    curve_object = bpy.data.objects.new(name, curve_data)
    bpy.context.collection.objects.link(curve_object)

    curve_object.data.bevel_depth = self.pipe_system.pipe_dimention[0] + self.pipe_system.pipe_dimention[1]/2
    curve_object.data.bevel_resolution = 2
    curve_object.data.use_fill_caps = True

    curve_object.select_set(True)
    bpy.context.view_layer.objects.active = curve_object
    bpy.ops.object.convert(target = "MESH")
    return curve_object


  def cut_out_with_boolean(self, stage_object, to_cut_sylinder):
    """Helper Function"""
    # need exact solver for all
    junction_modifier_name = "Boolean"
    stage_object.modifiers.new(junction_modifier_name, "BOOLEAN").object = to_cut_sylinder
    stage_object.modifiers[junction_modifier_name].operation = 'DIFFERENCE'
    stage_object.modifiers[junction_modifier_name].solver = "EXACT"
    stage_object.modifiers[junction_modifier_name].use_self = True
    stage_object.modifiers[junction_modifier_name].use_hole_tolerant = True

    # fully select before apply
    stage_object.select_set(True)
    bpy.context.view_layer.objects.active = stage_object
    bpy.ops.object.modifier_apply(modifier = junction_modifier_name)

    bpy.data.objects.remove(to_cut_sylinder)
    # to_cut_sylinder.hide_set(True)

    # mesh clean up
    stage_object.select_set(True)
    bpy.context.view_layer.objects.active = stage_object
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.vert_connect_nonplanar(angle_limit=0.001)
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.vert_connect_concave()
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.remove_doubles(threshold=0.002)
    bpy.ops.object.mode_set(mode = 'OBJECT')



  def add_guide_arrow(self, gate, stage):
    """
    Carve an arrow into the stage which points to the X direction of the logic gate
    Act as a guide during assembly
    """
    unit = self.unit_dimention

    # make arrow object
    bpy.ops.mesh.primitive_cube_add()
    arrow = bpy.context.active_object
    arrow.dimensions = (unit, .5*unit, .5*unit)
    bpy.ops.object.mode_set(mode = 'EDIT')

    bpy.ops.mesh.primitive_cylinder_add(
      location=(0.5*unit, 0, 0),
      rotation=(0, 0, -1.5708),
      vertices=3,
      radius=.6*unit,
      depth=.5*unit
    )
    bpy.ops.object.mode_set(mode = 'OBJECT')

    # calculate gate direction projected onto the stage
    x_unit = (1,0,0)
    origin = (0,0,0)
    loc = tuple(gate.location)
    rot = tuple(gate.rotation_euler)
    scl = tuple(gate.scale)
    new_x_unit = self.calculate_abs_pos((loc, rot, scl), x_unit)
    new_origin = self.calculate_abs_pos((loc, rot, scl), origin)

    proj_origin = (new_origin[0], new_origin[1], 0)
    proj_x_unit = (new_x_unit[0], new_x_unit[1], 0)

    dir_vector = np.subtract(proj_x_unit, proj_origin)

    angle_cos = np.dot(dir_vector, x_unit) / (np.linalg.norm(dir_vector) * np.linalg.norm(x_unit))

    rot_angle = acos(angle_cos)
    if dir_vector[1] < 0:
      rot_angle = 2*pi - rot_angle

    # top of stage
    proj_height = stage.location[2] + stage.dimensions[2]/2
    center_stage_loc = (stage.location[0], stage.location[1], proj_height)

    # place arrow
    arrow.location = center_stage_loc
    arrow.rotation_euler = (0,0,rot_angle)

    self.cut_out_with_boolean(stage, arrow)


  # apply transformations to relative port pos
  def calculate_abs_pos(self, placement_data, port_pos):
    """
    Helper function to calculate the absolute port position
    """

    # Linear Algibra, Euler rotation
    x,y,z = placement_data[1]
    # print("\n\nX,Y,Z to rotate",x,y,z)
    x_matrix = np.array([[1, 0, 0],\
                          [0, cos(x), -sin(x)],\
                          [0, sin(x), cos(x)]])

    y_matrix = np.array([[cos(y), 0, sin(y)],\
                          [0, 1, 0],\
                          [-sin(y), 0, cos(y)]])

    z_matrix = np.array([[cos(z), -sin(z), 0],\
                          [sin(z), cos(z), 0],\
                          [0, 0, 1]])

    # scale -> ratate -> move
    scaled_pos = list(map(lambda a,b: a*b, port_pos, placement_data[2]))

    vector_before = np.array([scaled_pos[0], scaled_pos[1], scaled_pos[2]])
    vector_after = np.dot(np.dot(z_matrix, y_matrix), np.dot(x_matrix, vector_before))
    rotated_pos = list(vector_after)

    moved_pos = list(map(lambda a,b: a+b, rotated_pos, placement_data[0]))
    rounded_pos = list(map(lambda a: round(a,2), moved_pos))

    # print(f"Port Pos: {port_pos} -> {rounded_pos}")
    return rounded_pos





  def add_tip(self, stl_path):
    """Add a custom tip stl to every tip of the tube"""

    # handles tip stl
    abs_path = bpy.path.abspath(stl_path)
    root,ext = os.path.splitext(abs_path)

    if not os.path.exists(abs_path):
      self.register_error_message(f"File Not Exist at {abs_path}")
      return

    if ext != ".stl":
      self.register_error_message(f"File is Not an STL file, file: {abs_path}")
      return

    json_path = root + ".json"
    if not os.path.exists(json_path):
      self.register_error_message(f"Corresponding Json file not found for file {abs_path}")
      return

    with open(json_path, 'r') as f:
      json_data = json.load(f)
      obj_base_name = json_data["Name"]
      obj_dim = list(json_data["Object Dimension"])
      pipe_dim = list(json_data["Pipe Dimension"])
      tip_radius = pipe_dim[0] + pipe_dim[1]

    target_radius = self.pipe_system.pipe_dimention[0] + self.pipe_system.pipe_dimention[1]
    target_scale = target_radius / tip_radius
    offset = self.tip_offset
    # add tip to each port
    added_coord = []
    tip_obj_list = []
    for connection in self.to_connect_list:
      for coord in connection:
        if coord not in added_coord:
          added_coord.append(coord)
          rounded_coord = tuple(map(lambda x: round(x,2), coord))
          bpy.ops.import_mesh.stl(filepath = abs_path)
          tip_obj = bpy.context.active_object
          tip_obj.name = f"{obj_base_name}-{rounded_coord}"
          tip_obj.scale = (target_scale, target_scale, target_scale)
          tip_obj.location = (coord[0], coord[1], coord[2]-offset)
          tip_obj_list.append(tip_obj)

    return tip_obj_list




  def reset_blender(self):
    """Call this function before everything to reset blender"""
    # delete all object (including invisible ones) excluding obstacles
    self.obstacle_list = self.get_obstacle_objects()
    for obj in bpy.data.objects:
      print(obj)
      if obj not in self.obstacle_list:
        bpy.data.objects.remove(obj)

    # set to object mode
    bpy.ops.mesh.primitive_cube_add()
    bpy.ops.object.mode_set(mode = "OBJECT")
    # delete cube
    bpy.ops.object.select_all(action='SELECT')
    bpy.data.objects.remove(bpy.context.active_object)
    # move cursor to origin
    bpy.context.scene.cursor.location = (0,0,0)
    # # scale using cursor as origin
    # bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'







  ##############################################  Print Helper  ##################################################


  def print_connection_dict(self):
    """Helper function"""
    print("\nConnection Dict:")
    for key,value in self.connection_dict.items():
      print(f"\tStart: {self.round_coord(key)}")
      for connection in value:
        print(f"Dest: {self.round_coord(connection[0])}, Propegation delay: {round(connection[1],4)}")

  def print_connection_group(self):
    """Helper function"""
    print("\nConnection Group:")
    for i,group in enumerate(self.connection_group_list):
      print(f"\tGroup {i}: {group}")

  def print_to_connect_list(self):
    """Helper function"""
    print("\nTo Connect list:")
    for item in self.to_connect_list:
      print(item)

  def register_error_message(self, error_message):
    """Helper Function"""
    self.error_message_list.append(error_message)
    print(error_message)

  def register_warning_message(self, warning_message):
    """Helper Function"""
    self.warning_message_list.append(warning_message)
    print(warning_message)

  def get_error_message(self):
    """Helper Function"""
    pipe_error_message = self.pipe_system.get_error_message()
    gate_error_message = []
    for gate in self.logic_gate_dict.values():
      gate_error_message.extend(gate.get_error_message())
    self.error_message_list.extend(pipe_error_message)
    self.error_message_list.extend(gate_error_message)
    return self.error_message_list

  def get_warning_message(self):
    """Helper Function"""
    pipe_warning_message = self.pipe_system.get_warning_message()
    gate_warning_message = []
    for gate in self.logic_gate_dict.values():
      gate_warning_message.extend(gate.get_warning_message())
    self.warning_message_list.extend(pipe_warning_message)
    self.warning_message_list.extend(gate_warning_message)
    return self.warning_message_list






if __name__ == '__main__':
  # bpy.ops.object.select_all(action='SELECT')
  # bpy.ops.object.delete(use_global=False)

  a = GateAssembly()

  a.reset_blender()

  gate1 = a.add_gate("g1", "/Users/lhwang/Documents/GitHub/RMG Project/Fluid-Circuit-Generator/STL/gate1.stl")
  gate2 = a.add_gate("g2", "/Users/lhwang/Documents/GitHub/RMG Project/Fluid-Circuit-Generator/STL/gate2.stl")
  gate1.move_gate(33,53,26)
  gate1.rotate_gate(15,26,37)
  gate1.scale_gate(1,3,.8)
  gate2.move_gate(13,17,20)
  gate2.scale_gate(.7,.7,.5)
  gate2.rotate_gate(5,5,30)

  a.add_free_end_port("f1", (10,40,10))
  a.add_free_end_port("f2", (45,10,10))

  if a.prepare_for_connection(pipe_dimention = (.5,.3), unit_dimention = 3, tip_length = 4, stage_height = 20, stage_margin = 2, tip_offset = 3):

    a.add_connection((gate1.name, "Sphere"), ("g2", "Cube"))
    a.add_connection((gate1.name, "Cube"), ("g2", "Cube"))
    a.add_connection(("g1", "Ring"), ("g2", "Ring"))
    a.add_connection(("g2", "Ring"), ("g2", "IcoSphere"))

    a.add_connection(("g1", "Ring"), ("g2", "IcoSphere"))
    a.add_connection(("g2", "Cone"), ("FREE_END", "f1"))
    a.add_connection(("FREE_END", "f2"), ("FREE_END", "f1"))

    a.make_connections()

    # print(a.connection_group_list)

    a.update_connection_dict()

    a.add_stage()
    a.add_tip("/Users/lhwang/Desktop/pipe_tip.stl")

    a.get_propagation_delay(("g2", "IcoSphere"), ("g1", "Cube"))
    a.get_propagation_delay(("g2", "IcoSphere"), ("g2", "Cube"))

    a.print_connection_group()
    print(a.get_warning_message())
    print(a.get_error_message())












